class test():
    def __init__(self,str:str) -> None:
        self.str=str
        print(str)