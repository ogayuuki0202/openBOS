# openBOS
the library of Background Oriented Schlieren
